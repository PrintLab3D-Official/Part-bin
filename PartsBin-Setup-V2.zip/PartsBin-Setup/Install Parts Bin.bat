@echo off
setlocal enableextensions
title Parts Bin - Installer

set "TARGET=%LOCALAPPDATA%\PartsBin"
set "SRC=%~dp0"

echo.
echo   ============================================
echo      Installing Parts Bin
echo   ============================================
echo.
echo   Copying app files to:
echo   %TARGET%
echo.

if not exist "%TARGET%" mkdir "%TARGET%"
if not exist "%TARGET%\PartsBin-assets" mkdir "%TARGET%\PartsBin-assets"

copy /Y "%SRC%PartsBin.html" "%TARGET%\" >nul
copy /Y "%SRC%PartsBin-assets\*" "%TARGET%\PartsBin-assets\" >nul
for %%F in (manifest.webmanifest sw.js icon.svg "Parts Bin.ico") do if exist "%SRC%%%~F" copy /Y "%SRC%%%~F" "%TARGET%\" >nul

set "HTMLPATH=%TARGET%\PartsBin.html"
set "ICONPATH=%TARGET%\Parts Bin.ico"

rem --- find Edge or Chrome for a clean app window ---
set "BROWSER="
if exist "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" set "BROWSER=%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe"
if exist "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe" set "BROWSER=%ProgramFiles%\Microsoft\Edge\Application\msedge.exe"
if not defined BROWSER if exist "%ProgramFiles%\Google\Chrome\Application\chrome.exe" set "BROWSER=%ProgramFiles%\Google\Chrome\Application\chrome.exe"
if not defined BROWSER if exist "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe" set "BROWSER=%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe"

echo   Creating shortcuts...
powershell -NoProfile -ExecutionPolicy Bypass -File "%SRC%make-shortcut.ps1"

echo.
echo   ============================================
echo      Done!  Look for "Parts Bin" on your
echo      Desktop and in the Start menu.
echo   ============================================
echo.
echo   You can delete this installer folder now -
echo   the app lives in the folder above.
echo.
pause
endlocal
exit /b 0
