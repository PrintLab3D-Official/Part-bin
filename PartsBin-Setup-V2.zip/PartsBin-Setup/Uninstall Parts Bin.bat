@echo off
setlocal
title Parts Bin - Uninstall

set "TARGET=%LOCALAPPDATA%\PartsBin"

echo.
echo   Removing Parts Bin and its shortcuts...
echo.

del "%USERPROFILE%\Desktop\Parts Bin.lnk" 2>nul
del "%APPDATA%\Microsoft\Windows\Start Menu\Programs\Parts Bin.lnk" 2>nul
if exist "%TARGET%" rmdir /S /Q "%TARGET%"

echo   Done. Parts Bin has been removed.
echo.
echo   NOTE: your saved inventory is stored by the browser, not in this
echo   folder. If you reinstall later it may still be there. To keep a
echo   copy for sure, use Settings ^> Backup to file BEFORE uninstalling.
echo.
pause
