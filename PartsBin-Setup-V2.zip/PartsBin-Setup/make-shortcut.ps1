# Creates Desktop + Start Menu shortcuts for Parts Bin.
# Reads paths from environment variables set by "Install Parts Bin.bat".

$htmlPath = $env:HTMLPATH
$browser  = $env:BROWSER
$uri      = ([Uri]$htmlPath).AbsoluteUri      # file:///C:/.../PartsBin.html (spaces -> %20)

if ([string]::IsNullOrEmpty($browser)) {
    # No Edge/Chrome found - open the file in the default browser instead.
    $target  = $htmlPath
    $argline = ''
} else {
    # Open in a clean app window (no browser tabs/bar).
    $target  = $browser
    $argline = '--app=' + $uri
}

$ws = New-Object -ComObject WScript.Shell
$targets = @(
    (Join-Path $env:USERPROFILE 'Desktop\Parts Bin.lnk'),
    (Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs\Parts Bin.lnk')
)

foreach ($lnk in $targets) {
    $s = $ws.CreateShortcut($lnk)
    $s.TargetPath = $target
    $s.Arguments  = $argline
    if ($env:ICONPATH -and (Test-Path $env:ICONPATH)) { $s.IconLocation = $env:ICONPATH }
    $s.WorkingDirectory = $env:TARGET
    $s.Save()
}

Write-Host "Shortcuts created on Desktop and Start menu."
