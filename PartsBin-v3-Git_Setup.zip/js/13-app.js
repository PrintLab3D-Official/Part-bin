/* =====================================================================
   Parts Bin — App boot: toast, sidebar resize, init sequence, service worker
   ===================================================================== */
let toastT;function toast(m){const t=$("#toast");t.textContent=m;t.classList.add("show");clearTimeout(toastT);toastT=setTimeout(()=>t.classList.remove("show"),2600)}

(function(){const sb=document.querySelector(".sidebar"),rz=$("#sbResize");if(!sb||!rz)return;const sw=+(localStorage.getItem("pb_sidebar")||0);if(sw>=170&&sw<=460)sb.style.width=sw+"px";let st=null;rz.addEventListener("pointerdown",e=>{st={x:e.clientX,w:sb.offsetWidth};try{rz.setPointerCapture(e.pointerId);}catch(_){}document.body.style.userSelect="none";e.preventDefault();});window.addEventListener("pointermove",e=>{if(!st)return;const w=Math.max(170,Math.min(460,st.w+(e.clientX-st.x)));sb.style.width=w+"px";});window.addEventListener("pointerup",()=>{if(st){localStorage.setItem("pb_sidebar",sb.offsetWidth);st=null;document.body.style.userSelect="";}});})();
labelSize=state.settings.labelSize||"md";wireSizeSeg("lblSizeSingle");wireSizeSeg("lblSizeSheet");syncSizeSeg();
applyStyle();applyFont();applyTheme();setGreeting();ensurePartIds();migrate();render();showLock();
/* Live clock + auto-receive now live in js/14-live.js (single heartbeat). */


/* ---------- PWA service worker (http only) ---------- */
/* PWA: register the offline/installable service worker only when hosted over http(s). Does nothing when opened as a local file. */
if('serviceWorker' in navigator && location.protocol.startsWith('http')){window.addEventListener('load',()=>{navigator.serviceWorker.register('sw.js').catch(()=>{});});}
