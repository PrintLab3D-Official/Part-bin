/* =====================================================================
   Parts Bin — Celebrate
   ---------------------------------------------------------------------
   Confetti burst + a green-bordered notification when a project is
   finished. Pure CSS/JS, no libraries, and it never touches your data.
   ===================================================================== */
const PB_CONFETTI_COLORS=["#22c55e","#3b82f6","#f59e0b","#ec4899","#a855f7","#06b6d4","#ef4444","#eab308"];

function pbConfetti(count){
  count=count||90;
  try{
    const box=document.createElement("div");
    box.className="pbconf";
    let html="";
    for(let i=0;i<count;i++){
      const c=PB_CONFETTI_COLORS[i%PB_CONFETTI_COLORS.length];
      const left=Math.random()*100;
      const dur=2.6+Math.random()*2.2;          /* fall time  */
      const delay=Math.random()*0.9;            /* stagger    */
      const w=6+Math.random()*7, h=9+Math.random()*10;
      const round=Math.random()<0.25?"border-radius:50%;":"";
      html+='<i style="left:'+left.toFixed(2)+'%;background:'+c+';width:'+w.toFixed(1)+'px;height:'+h.toFixed(1)+
            'px;'+round+'animation-duration:'+dur.toFixed(2)+'s;animation-delay:'+delay.toFixed(2)+'s"></i>';
    }
    box.innerHTML=html;
    document.body.appendChild(box);
    setTimeout(function(){ if(box.parentNode) box.parentNode.removeChild(box); },6200);
  }catch(e){}
}

/* Green-bordered notification. Auto-dismisses; click to close early. */
function pbNotify(title,msg,ms){
  try{
    const n=document.createElement("div");
    n.className="pbnotif";
    n.innerHTML='<div class="ic">'+ic("check")+'</div><div><div class="t">'+esc(title)+'</div>'+
                (msg?'<div class="m">'+esc(msg)+'</div>':'')+'</div>';
    document.body.appendChild(n);
    requestAnimationFrame(function(){ n.classList.add("show"); });
    const kill=function(){
      n.classList.remove("show");
      setTimeout(function(){ if(n.parentNode) n.parentNode.removeChild(n); },400);
    };
    n.onclick=kill;
    setTimeout(kill, ms||4600);
  }catch(e){}
}

/* Fired when a project's checklist is fully ticked off. */
function celebrateProject(name,archived){
  pbConfetti(110);
  try{ pbQueueNotify("projects","ok","Project completed",(name?name+" \u2014 ":"")+(archived?"moved into Archive":"all steps done")); }catch(e){}
}
