/* =====================================================================
   Parts Bin — What's New (V3 tour)
   ---------------------------------------------------------------------
   Opens instantly, once per version, and is re-openable from Settings.
   Slide 1 previews every style before Continue unlocks; the final slide
   asks you to drag a slider to finish. Notifications hold until it ends.

   TO ADD A SLIDE: append to WHATSNEW.slides and bump WHATSNEW.version.
   ===================================================================== */
const WHATSNEW={
  version:"3",
  slides:[
    { key:"hero", title:"Parts Bin V3",
      body:"The biggest update yet: a whole styling system, notifications that actually tell you things, smarter projects and orders, and proper safety for your inventory. Watch the styles cycle, then hit Continue.",
      gate:"styles" },

    { key:"styles", title:"Seven complete styles",
      body:"Settings → Style holds seven full re-skins. Each one changes the layout, fonts, spacing and colours — not just an accent. Warm Paper recentres the greeting as a serif masthead, Terminal adds CRT scanlines and a blinking cursor, Blueprint draws real grid paper, Aurora animates a live gradient behind frosted glass. Your existing Theme and Accent still work underneath every one of them." },

    { key:"notify", title:"Notifications that wait for you",
      body:"Alerts stack in the top-right and stay put until you dismiss them, each with an X that appears on hover. Three tones: a rising chime for good news, a softer fall for low stock, a heavier one for out of stock. Past three they collapse behind a Show all button. Anything raised while the app is locked queues up and slides in once you unlock." },

    { key:"projects", title:"Projects got hands-on",
      body:"Tick steps straight from the project card without opening it — finish the last one and you get confetti. Expand any card to double width for the full description, every step and every part. Parts now use plain Add and Remove buttons: Add pulls a unit out of your inventory, Remove puts it back, and the stock count updates live so you can never over-allocate." },

    { key:"orders", title:"Orders can receive themselves",
      body:"Turn on auto-receive in Settings and any order whose expected delivery date has passed adds its products straight into your inventory, then tells you exactly what landed.",
      warn:"This does not track live courier data. It only uses the expected delivery date you type in.",
      note:"Real carrier tracking needs the app hosted online \u2014 that can be set up separately." },

    { key:"discord", title:"Come join the Discord",
      body:"There's now a Support tab in the sidebar with every link in one place — Discord, YouTube, TikTok, GitHub and support email. The Discord is the fastest way to get help, report a bug, or suggest the next feature." },

    { key:"safety", title:"Your inventory is safe",
      body:"Every save writes a hidden recovery snapshot, and if the app ever loads to an empty inventory it restores itself automatically. Settings now has a separate Reset data and Uninstall everything, and Backup / Restore to a file any time.",
      warn:"Your inventory lives in this browser's storage. Clearing your browsing or site data will permanently erase it.",
      note:"Back up to a file regularly \u2014 that file is the only copy that survives a browser wipe or a move to another PC. Drag the slider to finish.",
      gate:"slider" }
  ]
};

/* Palettes used by the cycling preview on slide 1. */
const WN_PALETTES=[
  {k:"main", n:"Main",       bg:"#0d1117", bg2:"#161b22", line:"#2a3140", txt:"#e6edf3", ac:"#3b82f6"},
  {k:"claude", n:"Warm Paper", bg:"#f4efe6", bg2:"#fffdf9", line:"#e6ddcb", txt:"#2b2620", ac:"#c96442"},
  {k:"shopify", n:"Commerce",   bg:"#f1f2f4", bg2:"#ffffff", line:"#dfe3e8", txt:"#202223", ac:"#008060"},
  {k:"terminal", n:"Terminal",   bg:"#050805", bg2:"#0b110b", line:"#1e2b1e", txt:"#b9f5b9", ac:"#39ff14"},
  {k:"blueprint", n:"Blueprint",  bg:"#0a2144", bg2:"#0e2c58", line:"#2f66a8", txt:"#e6f0fb", ac:"#4cc9f0"},
  {k:"aurora", n:"Aurora",     bg:"linear-gradient(125deg,#6d28d9,#9d174d,#1e3a8a)", bg2:"rgba(255,255,255,.14)", line:"rgba(255,255,255,.3)", txt:"#f6f2ff", ac:"#f472b6"},
  {k:"neo", n:"Neo Brutal", bg:"#ffdd00", bg2:"#ffffff", line:"#111111", txt:"#111111", ac:"#ff5c00"}
];

let wnIdx=0, wnTimer=null, wnGateOpen=true, wnPrevStyle=null;

/* A small mock of the app, recoloured to preview each style. */
function wnMockHTML(){
  return '<div class="wn-mock" id="wnMock">'+
           '<div class="wm-side"><div class="wm-logo"></div>'+
             '<div class="wm-nav on"></div><div class="wm-nav"></div><div class="wm-nav"></div><div class="wm-nav"></div>'+
           '</div>'+
           '<div class="wm-main"><div class="wm-h"></div>'+
             '<div class="wm-stats"><i></i><i></i><i></i></div>'+
             '<div class="wm-cards"><i></i><i></i><i></i></div>'+
           '</div>'+
         '</div><div class="wn-mocklabel" id="wnMockLabel"></div>';
}
function wnPaintMock(p){
  const m=document.getElementById("wnMock"); if(!m) return;
  m.style.background=p.bg;
  m.style.setProperty("--wm-bg2",p.bg2);
  m.style.setProperty("--wm-line",p.line);
  m.style.setProperty("--wm-txt",p.txt);
  m.style.setProperty("--wm-ac",p.ac);
  const l=document.getElementById("wnMockLabel");
  if(l){ l.textContent=p.n; l.classList.remove("pop"); void l.offsetWidth; l.classList.add("pop"); }
}
/* Restore the user's real style after the preview. Only the DOM attribute
   is touched - state.settings.style is never written, so nothing persists. */
function wnRestoreStyle(){
  if(wnPrevStyle===null) return;
  document.body.setAttribute("data-style",wnPrevStyle);
  wnPrevStyle=null;
}
function wnApplyPreview(p){
  document.body.setAttribute("data-style",p.k);
  wnPaintMock(p);
}
function wnStartCycle(){
  let i=0;
  wnPrevStyle=(state.settings&&state.settings.style)||"main";
  wnGateOpen=false; wnSyncNext();
  wnApplyPreview(WN_PALETTES[0]);
  clearInterval(wnTimer);
  wnTimer=setInterval(function(){
    i++;
    if(i>=WN_PALETTES.length){
      clearInterval(wnTimer); wnTimer=null;
      wnRestoreStyle();                 /* back to normal */
      wnGateOpen=true; wnSyncNext();
      return;
    }
    wnApplyPreview(WN_PALETTES[i]);
  },780);
}


function wnArt(s){
  if(s.key==="hero")   return wnMockHTML();
  if(s.key==="styles") return '<div class="wn-styles">'+WN_PALETTES.map(function(p){
      return '<span style="background:'+p.bg+'"><i style="background:'+p.ac+'"></i></span>'; }).join("")+'</div>';
  if(s.key==="notify") return '<div class="wn-notes">'+
      '<div class="wn-note ok"><b>Order received</b><span>4 units added to inventory</span></div>'+
      '<div class="wn-note warn"><b>Low stock: M3 heat inserts</b><span>Only 2 left</span></div>'+
      '<div class="wn-note bad"><b>Out of stock: DC barrel jack</b><span>P-0002</span></div></div>';
  if(s.key==="projects") return '<div class="wn-proj">'+
      '<div class="wn-row done"><i></i>Solder the headers</div>'+
      '<div class="wn-row done"><i></i>Flash the firmware</div>'+
      '<div class="wn-row done"><i></i>Final bench test</div>'+
      '<div class="wn-btns"><span class="rm">Remove</span><span class="add">Add</span></div></div>';
  if(s.key==="orders") return '<div class="wn-order">'+
      '<div class="wn-pill">On the way · due today</div><div class="wn-arrow">↓</div>'+
      '<div class="wn-pill green">Added to inventory</div></div>';
  if(s.key==="discord") return '<div class="wn-discord"><div class="wn-dlogo">'+
      (typeof SUPPORT_ICONS!=="undefined"?SUPPORT_ICONS.discord:"")+'</div>'+
      '<div class="wn-dtag">discord.gg/n8M3V4SaHJ</div></div>';
  if(s.key==="safety") return '<div class="wn-safe"><div class="wn-shield">'+ic("check")+'</div>'+
      '<div class="wn-sbars"><i></i><i></i><i></i></div></div>';
  return "";
}

function wnSyncNext(){
  const btn=$("#wnNext"); if(!btn) return;
  const last=wnIdx===WHATSNEW.slides.length-1;
  btn.disabled=!wnGateOpen;
  btn.style.display=(last&&WHATSNEW.slides[wnIdx].gate==="slider")?"none":"inline-flex";
  const hint=$("#wnHint");
  if(hint) hint.textContent = wnGateOpen ? "" : "Previewing every style…";
}

function wnRender(){
  const s=WHATSNEW.slides[wnIdx], last=wnIdx===WHATSNEW.slides.length-1;
  clearInterval(wnTimer); wnTimer=null;
  wnRestoreStyle();
  const body=$("#wnBody");
  body.innerHTML='<div class="wn-slide"><div class="wn-art">'+wnArt(s)+'</div>'+
    '<h3 class="wn-title">'+esc(s.title)+'</h3>'+
    '<p class="wn-text">'+esc(s.body)+'</p>'+
    (s.warn?'<p class="wn-warn">'+esc(s.warn)+'</p>':'')+
    (s.note?'<p class="wn-note-sm">'+esc(s.note)+'</p>':'')+
    (s.gate==="slider"?'<div class="wn-slider"><input type="range" id="wnSlider" min="0" max="100" value="0" aria-label="Slide to finish"><span class="wn-slabel" id="wnSlabel">Slide to finish →</span></div>':'')+
    '</div>';
  const el=body.querySelector(".wn-slide");
  if(el){ void el.offsetWidth; el.classList.add("in"); }

  $("#wnDots").innerHTML=WHATSNEW.slides.map(function(_,i){
    return '<i class="'+(i===wnIdx?"on":(i<wnIdx?"done":""))+'"></i>'; }).join("");
  $("#wnBack").style.visibility = wnIdx===0 ? "hidden" : "visible";
  $("#wnStep").textContent=(wnIdx+1)+" of "+WHATSNEW.slides.length;

  wnGateOpen = s.gate!=="styles";
  wnSyncNext();
  if(s.gate==="styles") wnStartCycle();

  const sl=$("#wnSlider");
  if(sl){
    sl.oninput=function(){
      const v=+sl.value;
      const lab=$("#wnSlabel");
      if(lab) lab.style.opacity=String(Math.max(0,1-v/60));
      if(v>=98){ sl.disabled=true; closeWhatsNew(); }
    };
    sl.onchange=function(){ if(+sl.value<98) sl.value=0; };
    sl.onpointerup=function(){ if(+sl.value<98){ sl.value=0; const lab=$("#wnSlabel"); if(lab) lab.style.opacity="1"; } };
  }
}

function openWhatsNew(){ wnIdx=0; $("#wnOverlay").classList.add("show"); wnRender(); }
function closeWhatsNew(){
  clearInterval(wnTimer); wnTimer=null;
  wnRestoreStyle();
  $("#wnOverlay").classList.remove("show");
  try{ state.settings.seenVersion=WHATSNEW.version; persist(); }catch(e){}
  wnMaybeBackupPrompt();
  /* alerts were held back during the tour - let them through now */
  try{ pbFlushNotifications(); }catch(e){}
}
function wnNext(){
  if(!wnGateOpen) return;
  try{ pbSound("nav"); }catch(e){}
  if(wnIdx>=WHATSNEW.slides.length-1){ closeWhatsNew(); return; }
  wnIdx++; wnRender();
}
function wnBack(){ if(wnIdx>0){ try{ pbSound("nav"); }catch(e){} wnIdx--; wnRender(); } }

$("#wnNext").onclick=wnNext;
$("#wnBack").onclick=wnBack;
$("#wnClose").onclick=closeWhatsNew;
const _wb=$("#setWhatsNew"); if(_wb) _wb.onclick=openWhatsNew;

/* Show the tour once per version. If the PIN lock is up we can't show it
   yet, so this is called again the moment the app is unlocked - otherwise
   anyone using the app lock would never see the update notes at all. */
let wnAutoDone=false;
function wnMaybeAutoOpen(){
  try{
    if(wnAutoDone) return;
    if(state.settings.seenVersion===WHATSNEW.version) return;
    if(appLocked()) return;              /* try again after unlock */
    wnAutoDone=true;
    openWhatsNew();
  }catch(e){}
}
wnMaybeAutoOpen();

/* ---------- post-update nudge: back up your old data ---------- */
function wnMaybeBackupPrompt(){
  try{
    if(state.settings.backupPrompted===WHATSNEW.version) return;
    setTimeout(function(){ $("#wnBackupOverlay").classList.add("show"); },420);
  }catch(e){}
}
function wnCloseBackup(){
  $("#wnBackupOverlay").classList.remove("show");
  try{ state.settings.backupPrompted=WHATSNEW.version; persist(); }catch(e){}
}
const _bkNow=$("#wnBackupNow");
if(_bkNow) _bkNow.onclick=function(){
  try{ doBackup(); }catch(e){}
  wnCloseBackup();
};
const _bkLater=$("#wnBackupLater"); if(_bkLater) _bkLater.onclick=wnCloseBackup;
