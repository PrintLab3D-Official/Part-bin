/* =====================================================================
   Parts Bin — Inventory list: stats, render, item cards, quantity steppers
   ===================================================================== */
/* ---------- render ---------- */
function scopeItems(){return state.tab==="all"?state.items.slice():state.items.filter(i=>i.type===state.tab)}
function isLow(it){return it.low>0&&Number(it.qty)<=Number(it.low)}
function render(){
  updateAddBtn();
  if(state.tab==="projects"){renderProjects();return;}
  if(state.tab==="orders"){renderOrders();return;}
  if(state.tab==="archive"){renderArchive();return;}
  if(state.tab==="compartments"){renderCompartments();return;}
  $("#toolbar").style.display="flex";$("#subhead").textContent="electronics, filament & PCBs";
  const q=$("#search").value.toLowerCase().trim();const sort=$("#sortSel").value,lowOnly=$("#lowSel").value==="low";
  let list=scopeItems();
  const total=list.length,lowCount=list.filter(isLow).length,outCount=list.filter(i=>Number(i.qty)===0).length;
  const value=list.reduce((s,i)=>s+(Number(i.price||0)*Number(i.qty||0)),0);
  const units=list.reduce((s,i)=>s+Number(i.qty||0),0);
  const unitWord=state.tab==="all"?"Items":TYPES[state.tab].unit;
  $("#stats").innerHTML=`<div class="stat"><div class="n">${total}</div><div class="l">${unitWord}</div></div><div class="stat"><div class="n">${units}</div><div class="l">Total units</div></div><div class="stat warn"><div class="n">${lowCount}</div><div class="l">Low stock</div></div><div class="stat danger"><div class="n">${outCount}</div><div class="l">Out of stock</div></div><div class="stat"><div class="n">${money(value)}</div><div class="l">Inventory value</div></div>`;
  if(q)list=list.filter(i=>(i.name+" "+(i.partId||"")+" "+(i.loc||"")+" "+(i.material||"")+" "+(i.colorName||"")+" "+(i.code||"")).toLowerCase().includes(q));
  if(lowOnly)list=list.filter(isLow);
  list.sort((a,b)=>{if(sort==="name")return a.name.localeCompare(b.name);if(sort==="id")return (a.partId||"").localeCompare(b.partId||"");if(sort==="qtyAsc")return a.qty-b.qty;if(sort==="qtyDesc")return b.qty-a.qty;if(sort==="valDesc")return (b.price*b.qty)-(a.price*a.qty);});
  const grid=$("#grid");
  if(!list.length){grid.innerHTML=`<div class="empty" style="grid-column:1/-1"><div class="big">${ic("box")}</div>${q||lowOnly?"No matching items.":"Nothing here yet. Hit <b>Add item</b> to start."}</div>`;return;}
  grid.innerHTML=list.map(card).join("");
  list.forEach(it=>{
    grid.querySelector(`[data-edit="${it.id}"]`).onclick=()=>openModal(it.id);
    grid.querySelector(`[data-label="${it.id}"]`).onclick=()=>openLabel(it.id);
    const exp=grid.querySelector(`[data-exp="${it.id}"]`);if(exp)exp.onclick=e=>{e.stopPropagation();const c=exp.closest(".card");c.classList.toggle("expanded");if(expanded.has(it.id))expanded.delete(it.id);else expanded.add(it.id);};
    const di=grid.querySelector(`[data-inc="${it.id}"]`);if(di)di.onclick=()=>bump(it.id,1,false);
    const dd=grid.querySelector(`[data-dec="${it.id}"]`);if(dd)dd.onclick=()=>bump(it.id,-1,false);
    const ui=grid.querySelector(`[data-incu="${it.id}"]`);if(ui)ui.onclick=()=>bump(it.id,1,true);
    const ud=grid.querySelector(`[data-decu="${it.id}"]`);if(ud)ud.onclick=()=>bump(it.id,-1,true);
  });
}
function card(it){
  const low=isLow(it);const out=Number(it.qty)===0;const shop=shopName(it.link);const T=TYPES[it.type]||TYPES.components;
  const fit=it.imgFit||"cover",pos=it.imgPos||"50% 50%";const z=it.imgZoom||1;const tf=fit==='cover'&&z!==1?`;transform:scale(${z});transform-origin:${pos}`:'';
  const img=it.img?`<img src="${esc(it.img)}" referrerpolicy="no-referrer" data-t="${it.type}" style="object-fit:${fit};object-position:${pos}${tf}" onerror="imgFail(this)">`:`<div class="ph">${ic(T.icon)}</div>`;
  const swatch=it.type==='filament'&&it.color?`<div class="swatch" style="background:${it.color}"></div>`:"";
  const lowText=shop?`Low stock — reorder at ${esc(shop)}`:`LOW STOCK`;
  const meta=[];
  meta.push(`<span class="chip">${ic("id")}<b>${esc(it.partId||"—")}</b></span>`);
  if(state.tab==="all")meta.push(`<span class="chip">${ic(T.icon)} ${T.one}</span>`);
  if(it.type==='filament'){if(it.material)meta.push(`<span class="chip"><b>${esc(it.material)}</b></span>`);if(it.dia)meta.push(`<span class="chip">${esc(it.dia)}</span>`);if(it.colorName)meta.push(`<span class="chip">${esc(it.colorName)}</span>`);if(it.weight)meta.push(`<span class="chip">${esc(it.weight)} g left</span>`);}
  const inDrawer=compartmentOf(it.id);const ploc=inDrawer||it.loc;if(ploc)meta.push(`<span class="chip">${ic(inDrawer?"grid":"pin")}<b>${esc(ploc)}</b></span>`);
  if(it.code)meta.push(`<span class="chip">${ic("code")} ${esc(it.code)}</span>`);
  if(it.price>0)meta.push(`<span class="chip">${money(it.price)} ea</span>`);
  const isPack=it.perPack>0;const packs=isPack?(+(it.qty/it.perPack).toFixed(2)):it.qty;const qtyHtml=isPack?`<span class="num">${packs}</span><span style="color:var(--mut)">${packs===1?'pack':'packs'} · <b style="color:var(--txt)">${it.qty}</b> units</span>`:`<span class="num">${it.qty}</span><span style="color:var(--mut)">in stock</span>`;
  const unitRow=`<div class="ctlrow"><span class="ctll">${isPack?'Exact units (e.g. one broke)':'Quantity'}</span><div class="stepper"><button data-decu="${it.id}">−</button><span class="ctlv">${it.qty}</span><button data-incu="${it.id}">+</button></div></div>`;
  const packRowC=isPack?`<div class="ctlrow"><span class="ctll">Whole packs (×${it.perPack})</span><div class="stepper"><button data-dec="${it.id}">−</button><span class="ctlv">${packs}</span><button data-inc="${it.id}">+</button></div></div>`:``;
  const controls=packRowC+unitRow;
  const qtyBlock=isPack
    ? `<div class="qty">${qtyHtml}<button class="iconbtn expandbtn" data-exp="${it.id}" title="Adjust stock">${ic("chev")}</button></div><div class="controls">${controls}</div>`
    : `<div class="qty">${qtyHtml}<div class="stepper"><button data-decu="${it.id}">−</button><button data-incu="${it.id}">+</button></div></div>`;
  const buy=it.link?`<a href="${esc(it.link)}" target="_blank" rel="noopener"><div class="buybtn">${ic("cart")} ${shop?'Buy at '+esc(shop):'Buy more'}</div></a>`:`<div class="buybtn disabled" style="flex:1">No link</div>`;
  const badge=out?`<div class="outbadge">${ic("warn")}OUT OF STOCK</div>`:(low?`<div class="lowbadge">${ic("warn")}${lowText}</div>`:`<div class="pid">${esc(it.partId||'')}</div>`);
  return `<div class="card ${out?'out':low?'low':''} ${expanded.has(it.id)?'expanded':''}" data-card="${it.id}"><div class="thumb">${img}${badge}${swatch}</div><div class="cbody"><div class="cname">${esc(it.name)}</div><div class="meta">${meta.join("")}</div>${qtyBlock}</div><div class="cfoot">${buy}<button class="iconbtn" data-label="${it.id}" title="Barcode label">${ic("tag")}</button><button class="iconbtn" data-edit="${it.id}" title="Edit">${ic("edit")}</button></div></div>`;
}
const expanded=new Set();
function bump(id,d,unit){const it=state.items.find(i=>i.id===id);if(!it)return;const step=unit?1:(it.perPack>0?it.perPack:1);it.qty=Math.max(0,Number(it.qty)+d*step);persist();render()}

