/* =====================================================================
   Parts Bin — Backup / restore to JSON file
   ===================================================================== */
/* backup / restore */
function doBackup(){const blob=new Blob([JSON.stringify({app:"PartsBin",version:8,items:state.items,projects:state.projects,orders:state.orders,compartments:state.compartments,materials:state.materials,locations:state.locations,settings:state.settings},null,2)],{type:"application/json"});const a=document.createElement("a");a.href=URL.createObjectURL(blob);a.download="parts-bin-backup-"+new Date().toISOString().slice(0,10)+".json";a.click();toast("Backup downloaded");}
const restoreInput=document.createElement("input");restoreInput.type="file";restoreInput.accept="application/json";restoreInput.style.display="none";document.body.appendChild(restoreInput);
restoreInput.onchange=e=>{const f=e.target.files[0];if(!f)return;const r=new FileReader();r.onload=()=>{try{const d=JSON.parse(r.result);if(!d.items)throw 0;if(!confirm("Restore "+d.items.length+" items? This replaces your current data."))return;state.items=d.items;if(d.projects)state.projects=d.projects;if(d.orders)state.orders=d.orders;if(d.compartments)state.compartments=d.compartments;if(d.materials)state.materials=d.materials;if(d.locations)state.locations=d.locations;if(d.settings)state.settings=d.settings;ensurePartIds();persist();render();toast("Restored "+d.items.length+" items");}catch(x){toast("Invalid backup file")}};r.readAsText(f);e.target.value="";};

