/* =====================================================================
   Parts Bin — Compartments: storage units, drawers, placement picker
   ===================================================================== */
/* ---------- compartments ---------- */
function renderCompartments(){
  $("#toolbar").style.display="none";$("#subhead").textContent="your shelves, cabinets & drawers";
  const list=state.compartments;
  const drawers=list.reduce((s,c)=>s+((c.cells||[]).length),0);
  const used=list.reduce((s,c)=>s+((c.cells||[]).filter(x=>x&&(x.label||x.itemId)).length),0);
  $("#stats").innerHTML=`<div class="stat"><div class="n">${list.length}</div><div class="l">Storage units</div></div><div class="stat"><div class="n">${drawers}</div><div class="l">Total drawers</div></div><div class="stat"><div class="n">${used}</div><div class="l">Drawers filled</div></div>`;
  const grid=$("#grid");
  if(!list.length){grid.innerHTML=`<div class="empty" style="grid-column:1/-1"><div class="big">${ic("grid")}</div>No storage yet. Hit <b>New compartment</b> to map a shelf or drawer cabinet.</div>`;return;}
  grid.innerHTML=list.map(compCard).join("");
  list.forEach(c=>{const card=grid.querySelector(`[data-comp="${c.id}"]`);if(!card)return;const e=card.querySelector("[data-compedit]");if(e)e.onclick=()=>openComp(c.id);card.querySelectorAll("[data-cell]").forEach(d=>d.onclick=()=>openCell(c.id,+d.dataset.cell));});
}
function compCard(c){
  const cells=c.cells||[];
  const drawers=cells.map((cell,i)=>{const it=(cell&&cell.itemId)?state.items.find(x=>x.id===cell.itemId):null;const txt=(cell&&cell.label)||(it?it.name:"");const filled=!!((cell&&cell.label)||it);return `<div class="drawer ${filled?'filled':''}" data-cell="${i}" title="${esc(txt||('Drawer '+(i+1)))}"><span>${esc(txt||"")}</span></div>`;}).join("");
  const meta=[`<span class="chip">${c.rows}×${c.cols}</span>`,`<span class="chip">${cells.length} drawers</span>`];
  if(c.loc)meta.unshift(`<span class="chip">${ic("pin")}<b>${esc(c.loc)}</b></span>`);
  return `<div class="ccard" data-comp="${c.id}"><div class="cchead"><div class="cname">${esc(c.name)}</div><button class="iconbtn" data-compedit="${c.id}" title="Edit size / name">${ic("edit")}</button></div><div class="meta">${meta.join("")}</div><div class="drawergrid" style="grid-template-columns:repeat(${c.cols},1fr)">${drawers}</div></div>`;
}
function compartmentOf(itemId){for(const c of state.compartments){const cells=c.cells||[];for(let i=0;i<cells.length;i++){if(cells[i]&&cells[i].itemId===itemId)return c.name+" · #"+(i+1);}}return "";}
function findPlacement(itemId){for(const c of state.compartments){const cells=c.cells||[];for(let i=0;i<cells.length;i++){if(cells[i]&&cells[i].itemId===itemId)return {compId:c.id,idx:i};}}return null;}
function locOf(it){return compartmentOf(it.id)||it.loc||"";}
let compEdit=null;
function openComp(id){
  const c=id?state.compartments.find(x=>x.id===id):null;compEdit=id||null;
  $("#compTitle").textContent=id?"Edit compartment":"New compartment";
  $("#compName").value=c?c.name:"";$("#compRows").value=c?c.rows:6;$("#compCols").value=c?c.cols:3;$("#compLoc").value=c?(c.loc||""):"";
  $("#compDelete").style.display=id?"inline-flex":"none";
  renderCompPreview();$("#compOverlay").classList.add("show");$("#compName").focus();
}
function clampN(v,lo,hi){v=parseInt(v,10);if(isNaN(v))v=lo;return Math.max(lo,Math.min(hi,v));}
function renderCompPreview(){const r=clampN($("#compRows").value,1,20),c=clampN($("#compCols").value,1,20);const g=$("#compPreview");g.style.gridTemplateColumns=`repeat(${c},1fr)`;g.innerHTML=Array(r*c).fill('<div class="ppcell"></div>').join("");}
$("#compRows").oninput=renderCompPreview;$("#compCols").oninput=renderCompPreview;
function closeComp(){$("#compOverlay").classList.remove("show");}
$("#compClose").onclick=closeComp;$("#compOverlay").onclick=e=>{if(e.target===$("#compOverlay"))closeComp();};
$("#compDelete").onclick=()=>{if(!confirm("Delete this compartment? Its drawer labels will be lost (parts stay in inventory)."))return;state.compartments=state.compartments.filter(x=>x.id!==compEdit);persist();closeComp();render();toast("Compartment deleted");};
$("#compSave").onclick=()=>{
  const name=$("#compName").value.trim();if(!name)return toast("Give it a name");
  const rows=clampN($("#compRows").value,1,20),cols=clampN($("#compCols").value,1,20);
  const loc=$("#compLoc").value.trim();if(loc&&!state.locations.some(l=>l.toLowerCase()===loc.toLowerCase()))state.locations.push(loc);
  if(compEdit){const c=state.compartments.find(x=>x.id===compEdit);const old=c.cells||[],oc=c.cols||cols,or=c.rows||rows;const nc=[];for(let i=0;i<rows*cols;i++){const rr=Math.floor(i/cols),cc=i%cols;const oi=rr*oc+cc;nc.push((rr<or&&cc<oc&&old[oi])?old[oi]:{label:"",itemId:""});}Object.assign(c,{name,rows,cols,loc,cells:nc});}
  else{const cells=Array.from({length:rows*cols},()=>({label:"",itemId:""}));state.compartments.push({id:uid(),name,rows,cols,loc,cells});}
  persist();closeComp();render();toast("Compartment saved");
};
let cellComp=null,cellIdx=-1;
function openCell(compId,idx){
  const c=state.compartments.find(x=>x.id===compId);if(!c)return;cellComp=compId;cellIdx=idx;
  if(!c.cells[idx])c.cells[idx]={label:"",itemId:""};
  const cell=c.cells[idx];
  $("#cellTitle").textContent=c.name+" — drawer "+(idx+1);
  $("#cellLabel").value=cell.label||"";
  $("#cellItem").innerHTML='<option value="">— none —</option>'+state.items.map(i=>`<option value="${i.id}" ${cell.itemId===i.id?"selected":""}>${esc((i.partId?i.partId+" — ":"")+i.name)}</option>`).join("");
  $("#cellOverlay").classList.add("show");$("#cellLabel").focus();
}
function closeCell(){$("#cellOverlay").classList.remove("show");}
$("#cellClose").onclick=closeCell;$("#cellOverlay").onclick=e=>{if(e.target===$("#cellOverlay"))closeCell();};
$("#cellClear").onclick=()=>{const c=state.compartments.find(x=>x.id===cellComp);if(c&&c.cells[cellIdx]){c.cells[cellIdx]={label:"",itemId:""};persist();}closeCell();render();toast("Drawer cleared");};
$("#cellSave").onclick=()=>{const c=state.compartments.find(x=>x.id===cellComp);if(c){const ni=$("#cellItem").value||"";if(ni)state.compartments.forEach(cc=>(cc.cells||[]).forEach((cell,i)=>{if(cell&&cell.itemId===ni&&!(cc.id===cellComp&&i===cellIdx))cell.itemId="";}));c.cells[cellIdx]={label:$("#cellLabel").value.trim(),itemId:ni};persist();}closeCell();render();toast("Drawer updated");};
/* ---------- placement picker (from item form) ---------- */
let placeSel=null;
function updatePlaceLabel(){const el=$("#fPlaceLabel");if(!el)return;if(placeSel){const c=state.compartments.find(x=>x.id===placeSel.compId);el.innerHTML=c?(ic("grid")+" "+esc(c.name)+" · drawer "+(placeSel.idx+1)):"Not in a compartment";}else{el.textContent="Not in a compartment";}}
function openPlace(){if(!state.compartments.length){toast("Make a compartment first (Compartments tab)");return;}
  const sel=$("#placeComp");sel.innerHTML=state.compartments.map(c=>`<option value="${c.id}">${esc(c.name)} (${c.rows}×${c.cols})</option>`).join("");
  sel.value=(placeSel&&placeSel.compId)||state.compartments[0].id;renderPlaceGrid();$("#placeOverlay").classList.add("show");}
function renderPlaceGrid(){const c=state.compartments.find(x=>x.id===$("#placeComp").value);const g=$("#placeGrid");if(!c){g.innerHTML="";return;}
  g.style.gridTemplateColumns=`repeat(${c.cols},1fr)`;
  g.innerHTML=(c.cells||[]).map((cell,i)=>{const it=(cell&&cell.itemId)?state.items.find(x=>x.id===cell.itemId):null;const mine=state.editId&&cell&&cell.itemId===state.editId;const txt=mine?"this part":((cell&&cell.label)||(it?it.name:""));const sel=placeSel&&placeSel.compId===c.id&&placeSel.idx===i;const filled=!!((cell&&cell.label)||it);return `<div class="drawer ${filled?'filled':''} ${sel?'psel':''}" data-pi="${i}" title="${esc(txt||('Drawer '+(i+1)))}"><span>${esc(txt||(i+1))}</span></div>`;}).join("");
  g.querySelectorAll("[data-pi]").forEach(d=>d.onclick=()=>{placeSel={compId:c.id,idx:+d.dataset.pi};updatePlaceLabel();closePlace();});}
function closePlace(){$("#placeOverlay").classList.remove("show");}
$("#placeComp").onchange=renderPlaceGrid;
$("#placeClose").onclick=closePlace;$("#placeOverlay").onclick=e=>{if(e.target===$("#placeOverlay"))closePlace();};
$("#placeNone").onclick=()=>{placeSel=null;updatePlaceLabel();closePlace();};
$("#fPlaceBtn").onclick=openPlace;
