/* =====================================================================
   Parts Bin — Labels: Code-39 barcodes, single + sheet printing
   ===================================================================== */
/* ---------- Code 39 barcode ---------- */
const C39={"0":"111221211","1":"211211112","2":"112211112","3":"212211111","4":"111221112","5":"211221111","6":"112221111","7":"111211212","8":"211211211","9":"112211211","A":"211112112","B":"112112112","C":"212112111","D":"111122112","E":"211122111","F":"112122111","G":"111112212","H":"211112211","I":"112112211","J":"111122211","K":"211111122","L":"112111122","M":"212111121","N":"111121122","O":"211121121","P":"112121121","Q":"111111222","R":"211111221","S":"112111221","T":"111121221","U":"221111112","V":"122111112","W":"222111111","X":"121121112","Y":"221121111","Z":"122121111","-":"121111212",".":"221111211"," ":"122111211","$":"121212111","/":"121211121","+":"121112121","%":"111212121","*":"121121211"};
function code39SVG(data){data=String(data).toUpperCase().replace(/[^0-9A-Z\-\. \$\/\+%]/g,"");const seq="*"+data+"*";const N=1,W=3,h=90,M=14;let x=M;const r=[];for(let c=0;c<seq.length;c++){const pat=C39[seq[c]];if(!pat)continue;for(let i=0;i<9;i++){const w=(pat[i]==="2"?W:N);if(i%2===0)r.push(`<rect x="${x}" y="0" width="${w}" height="${h}"/>`);x+=w;}x+=N;}const total=x+M;return `<svg viewBox="0 0 ${total} ${h}" preserveAspectRatio="none" xmlns="http://www.w3.org/2000/svg"><rect x="0" y="0" width="${total}" height="${h}" fill="#fff"/><g fill="#000">${r.join("")}</g></svg>`;}
let labelId=null;
function buildLabel(it){const l=locOf(it);return `<div class="plabel"><div class="ln">${esc(it.name)}</div>${code39SVG(it.partId||"PART")}<div class="lid">${esc(it.partId||"")}</div><div class="lloc">${l?"@ "+esc(l):""}</div></div>`;}
let labelSize="md";
function wireSizeSeg(id){const g=$("#"+id);if(!g)return;g.querySelectorAll(".segbtn").forEach(b=>b.onclick=()=>{labelSize=b.dataset.sz;state.settings.labelSize=labelSize;persist();document.querySelectorAll("#lblSizeSingle .segbtn,#lblSizeSheet .segbtn").forEach(x=>x.classList.toggle("on",x.dataset.sz===labelSize));});}
function syncSizeSeg(){document.querySelectorAll("#lblSizeSingle .segbtn,#lblSizeSheet .segbtn").forEach(x=>x.classList.toggle("on",x.dataset.sz===labelSize));}
function printLabels(items){if(!items.length)return;const pa=$("#printArea");pa.className=(items.length>1?"pa-sheet":"pa-single")+" pa-"+(labelSize||"md");pa.innerHTML=items.map(buildLabel).join("");document.body.classList.add("printing");window.print();}
function openLabel(id){const it=state.items.find(i=>i.id===id);if(!it)return;labelId=id;$("#lpName").textContent=it.name;$("#lpId").textContent=it.partId||"";$("#lpLoc").textContent=locOf(it)?("@ "+locOf(it)):"";$("#lpBar").innerHTML=code39SVG(it.partId||"PART");syncSizeSeg();$("#lpCopies").value=1;$("#labelOverlay").classList.add("show");}
$("#labelClose").onclick=()=>$("#labelOverlay").classList.remove("show");
$("#labelOverlay").onclick=e=>{if(e.target===$("#labelOverlay"))$("#labelOverlay").classList.remove("show")};
document.querySelectorAll("#labelOverlay [data-cp]").forEach(b=>b.onclick=()=>{$("#lpCopies").value=b.dataset.cp;});
$("#labelPrintBtn").onclick=()=>{const it=state.items.find(i=>i.id===labelId);if(!it)return;const n=Math.max(1,Math.min(200,Number($("#lpCopies").value)||1));printLabels(Array.from({length:n},()=>it));};
window.addEventListener("afterprint",()=>{document.body.classList.remove("printing");$("#printArea").innerHTML="";$("#printArea").className="";});

/* multi-label sheet */
function openSheet(){
  const list=scopeItems();
  if(!list.length)return toast("Nothing here to print");
  $("#selList").innerHTML=list.map(i=>`<label class="selrow"><input type="checkbox" class="selitem" value="${i.id}" checked><span>${esc(i.partId||'')} — ${esc(i.name)}</span></label>`).join("");
  $("#selAll").checked=true;updateSelCount();
  $("#selList").querySelectorAll(".selitem").forEach(c=>c.onchange=updateSelCount);
  syncSizeSeg();$("#sheetOverlay").classList.add("show");
}
function updateSelCount(){const n=[...document.querySelectorAll(".selitem:checked")].length;$("#selCount").textContent=n+" selected";}
$("#labelsBtn").onclick=openSheet;
$("#sheetClose").onclick=()=>$("#sheetOverlay").classList.remove("show");
$("#sheetOverlay").onclick=e=>{if(e.target===$("#sheetOverlay"))$("#sheetOverlay").classList.remove("show")};
$("#selAll").onchange=()=>{document.querySelectorAll(".selitem").forEach(c=>c.checked=$("#selAll").checked);updateSelCount();};
$("#sheetPrintBtn").onclick=()=>{const ids=[...document.querySelectorAll(".selitem:checked")].map(c=>c.value);if(!ids.length)return toast("Select at least one");const items=ids.map(id=>state.items.find(x=>x.id===id)).filter(Boolean);$("#sheetOverlay").classList.remove("show");printLabels(items);};

