/* =====================================================================
   Parts Bin — Scanner: ZXing camera scan + scan-to-find
   ===================================================================== */
/* ---------- scanner (ZXing + manual Scan now) ---------- */
let zxReader=null,scanCb=null;
function ensureReader(){if(!zxReader&&window.ZXing){try{let hints=null;try{if(ZXing.DecodeHintType&&ZXing.DecodeHintType.TRY_HARDER!==undefined){hints=new Map();hints.set(ZXing.DecodeHintType.TRY_HARDER,true);}}catch(_){}zxReader=hints?new ZXing.BrowserMultiFormatReader(hints):new ZXing.BrowserMultiFormatReader();}catch(e){try{zxReader=new ZXing.BrowserMultiFormatReader();}catch(e2){}}}return zxReader;}
async function primeCams(){
  try{const tmp=await navigator.mediaDevices.getUserMedia({video:true});tmp.getTracks().forEach(t=>t.stop());}catch(e){}
  try{
    const devs=(await navigator.mediaDevices.enumerateDevices()).filter(d=>d.kind==="videoinput");
    if(devs.length){
      const sel=$("#camSel");sel.innerHTML=devs.map((d,i)=>`<option value="${d.deviceId}">${esc(d.label||("Camera "+(i+1)))}</option>`).join("");
      const saved=localStorage.getItem("pb_camera");
      if(saved&&devs.some(d=>d.deviceId===saved))sel.value=saved;
      else{const real=devs.find(d=>!/obs|virtual|snap|droidcam/i.test(d.label||""));sel.value=(real||devs[0]).deviceId;}
    }
  }catch(e){}
}
async function startScan(){
  const r=ensureReader();
  if(!r){$("#scanMsg").textContent="Scanner engine missing — keep zxing.min.js in the app's assets folder.";return;}
  $("#scanMsg").textContent="Starting camera…";
  await primeCams();
  const dev=$("#camSel").value;
  $("#scanMsg").textContent="Hold the barcode in the box (~20cm away, filling the frame). Tap Scan now if it doesn't auto-catch.";
  const constraints={video:{width:{ideal:1280},height:{ideal:720}}};
  if(dev)constraints.video.deviceId={ideal:dev};else constraints.video.facingMode={ideal:"environment"};
  try{
    await r.decodeFromConstraints(constraints,$("#scanVideo"),(result)=>{if(result)onScan(result.getText());});
  }catch(e){
    try{await r.decodeFromVideoDevice(dev||undefined,$("#scanVideo"),(result)=>{if(result)onScan(result.getText());});}
    catch(e2){$("#scanMsg").textContent="Couldn't open this camera ("+((e2&&e2.message)||(e&&e.message)||"error")+"). Pick another above.";}
  }
}
function stopScan(){try{zxReader&&zxReader.reset();}catch(e){}}
function onScan(text){const cb=scanCb;closeScanner();if(cb)cb(text);}
function openScanner(title,cb){scanCb=cb;$("#scanTitle").textContent=title;$("#scanManual").value="";$("#scanMsg").textContent="Starting camera…";$("#scanOverlay").classList.add("show");startScan();}
function closeScanner(){stopScan();$("#scanOverlay").classList.remove("show");}
$("#camSel").onchange=()=>{localStorage.setItem("pb_camera",$("#camSel").value);stopScan();startScan();};
$("#scanNowBtn").onclick=async()=>{
  const r=ensureReader();if(!r)return;
  const v=$("#scanVideo");
  if(!v.videoWidth){$("#scanMsg").textContent="Camera still starting — wait a second and tap again.";return;}
  try{
    const c=document.createElement("canvas");c.width=v.videoWidth;c.height=v.videoHeight;c.getContext("2d").drawImage(v,0,0,c.width,c.height);
    const res=await r.decodeFromImageUrl(c.toDataURL("image/png"));
    if(res)onScan(res.getText());
  }catch(e){$("#scanMsg").textContent="No code read — fill the box with the barcode, hold steady, tap Scan now.";}
};
$("#scanClose").onclick=closeScanner;
$("#scanOverlay").onclick=e=>{if(e.target===$("#scanOverlay"))closeScanner()};
$("#scanManualGo").onclick=()=>{const v=$("#scanManual").value.trim();if(v)onScan(v)};
$("#scanManual").onkeydown=e=>{if(e.key==="Enter"){const v=$("#scanManual").value.trim();if(v)onScan(v)}};
$("#scanAddBtn").onclick=()=>openScanner("Scan to fill code",code=>{$("#fCode").value=code;toast("Code captured: "+code);});
$("#scanFindBtn").onclick=()=>openScanner("Scan to find item",code=>findByCode(code));
window.addEventListener("beforeunload",stopScan);
function findByCode(code){const c=code.trim().toLowerCase();const it=state.items.find(i=>(i.code||"").trim().toLowerCase()===c||(i.partId||"").toLowerCase()===c);if(!it){if(confirm('No item has code "'+code+'". Add a new item with this code?')){openModal(null);$("#fCode").value=code;}return;}state.tab="all";document.querySelectorAll(".navtab[data-tab]").forEach(x=>x.classList.toggle("active",x.dataset.tab==="all"));$("#search").value="";$("#lowSel").value="all";render();showScanResult(it);}
function showScanResult(it){const loc=locOf(it);const inDrawer=compartmentOf(it.id);const T=TYPES[it.type]||TYPES.components;const img=it.img?`<img src="${esc(it.img)}" referrerpolicy="no-referrer" style="width:88px;height:88px;border-radius:12px;object-fit:cover">`:`<div class="ph" style="width:88px;height:88px;border-radius:12px;display:grid;place-items:center;background:var(--bg3)">${ic(T.icon)}</div>`;
  $("#scanResultBody").innerHTML=`<div class="srcheck">${ic("check")}</div><div style="font-size:12px;color:var(--green);font-weight:700;letter-spacing:.6px;text-transform:uppercase">${esc(T.one)} scanned</div><div style="display:flex;gap:14px;align-items:center;justify-content:center;margin:14px 0"><div>${img}</div><div style="text-align:left"><div style="font-size:19px;font-weight:800;line-height:1.2">${esc(it.name)}</div><div style="color:var(--mut);font-size:13px;margin-top:3px">${esc(it.partId||"")} · ${it.qty} in stock</div></div></div><div style="font-size:12px;color:var(--mut);text-transform:uppercase;letter-spacing:.5px;margin-bottom:5px">Location</div><div class="srloc">${loc?`${ic(inDrawer?"grid":"pin")} <b>${esc(loc)}</b>`:`<span style="color:var(--mut)">No location set</span>`}</div><div style="display:flex;gap:8px;margin-top:18px"><button class="btn-ghost" id="srView" style="flex:1;justify-content:center">Show on shelf list</button><button class="btn-primary" id="srOk" style="flex:1;justify-content:center">Done</button></div>`;
  $("#scanResultOverlay").classList.add("show");
  $("#srOk").onclick=()=>$("#scanResultOverlay").classList.remove("show");
  $("#srView").onclick=()=>{$("#scanResultOverlay").classList.remove("show");const el=document.querySelector(`[data-card="${it.id}"]`);if(el){el.scrollIntoView({behavior:"smooth",block:"center"});el.classList.add("flash");setTimeout(()=>el.classList.remove("flash"),1300);}};}

