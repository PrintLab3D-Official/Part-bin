# Parts Bin V3

A free, offline inventory app for makers — electronics components, filament, PCBs, screws, storage
compartments, projects and incoming orders. It's a single local web app: no install, no account,
no server, and nothing leaves your PC.

![style presets](assets/logo.png)

---

## Install

1. Download this folder (Code → Download ZIP) and unzip it anywhere you like.
2. Double-click **Create Desktop Shortcut.bat** — this makes a "Parts Bin App" shortcut that opens
   the app in its own window with no browser tabs or address bar.
3. Open it from that shortcut.

You can also just open `Parts Bin.html` directly in any modern browser.

> Best experience is Microsoft Edge or Chrome. The shortcut uses Edge's app mode.

---

## Where your data lives

Your inventory is saved in **your browser's local storage on that PC** — not in these files.

That means:

* Your data never leaves your machine.
* Copying this folder to another computer gives you the app with an **empty inventory**.
* To move your data, use **Settings → Back up to file**, then **Restore from file** on the other machine.

Every save also writes a hidden recovery snapshot. If the app ever starts with an empty inventory
but a snapshot exists, it restores itself automatically.

### ⚠️ Read this before you rely on it

Your inventory is **not stored in a file**. It lives in your browser's local storage, which means:

* **Clearing your browsing data, cookies or "site data" will permanently erase your entire inventory.**
* Using your browser in private/incognito mode will not keep anything.
* Uninstalling or resetting the browser wipes it too.
* It does **not** sync or follow you to another computer.
* **All local copies on one PC share the same data.** Browsers treat every page opened
  from a file as the same site, so a second copy in a different folder is not a separate
  inventory — it is another window onto the same one. Updating or moving the app therefore
  keeps your data, but a Reset/Uninstall in any copy clears it for all of them.

The **only** copy that survives any of that is a backup file.
Use **Settings → Backup to file** regularly and keep that `.json` somewhere safe
(cloud drive, USB stick, anywhere that isn't just this browser).

---

## Upgrading from an older version

Just download V3, unzip it somewhere, and open it. **Your existing inventory appears
automatically** — you do not need to restore a backup.

That works because all local copies on one PC share the same browser storage, so V3 simply
picks up what the old version saved. Older projects are migrated to the new format on first
load, and the What's New tour will show you what changed.

Once it's running, **delete the old version's folder.** Nothing breaks if you don't, but both
folders open the same inventory, which gets confusing fast.

Take a backup first (**Settings → Backup to file**) if you'd rather be safe.

---

## Features

**Inventory** — components, filament, PCBs and screws with photos, quantities, prices, buy links,
locations, low-stock thresholds and auto-generated part IDs. Multi-pack tracking, search, sorting
and live inventory value.

**Compartments** — map real drawer cabinets and shelves, then assign parts to individual drawers.

**Projects** — photos, descriptions, parts lists and checklists. Add pulls units out of your
inventory, Remove puts them back. Tick steps straight from the project card; finish one and you get
confetti and an archive.

**Orders** — track incoming packages with products, prices, tracking numbers and expected dates.
Mark one arrived and its products flow into your inventory. Optional auto-receive on the expected date.

**Barcode labels & scanning** — print Code-39 labels for your parts, then scan with a webcam to find
an item instantly. Powered by [ZXing](https://github.com/zxing-js/library).

**7 style presets** — Main, Warm Paper, Commerce, Terminal, Blueprint, Aurora and Neo Brutal. Each is
a complete re-skin (layout, fonts, backgrounds), layered on top of 16 themes, custom accent colours
and font choices.

**Notifications** — in-app alerts for low stock, out of stock, orders received and completed projects,
with three tones, an optional chime and per-event toggles.

**Also** — app lock PIN, custom greeting, currency symbol, saved materials/locations, JSON
backup/restore, and a clean uninstaller.

---

## Known limitations

Because this runs as a local file (`file://`), the browser blocks two things:

* **Windows notifications** — permission is refused for local files, so alerts are drawn in-app instead.
* **Live courier tracking** — order auto-receive uses the **expected date you enter**, not real carrier
  data. Live tracking needs the app hosted online with a serverless function holding an API key.

Sound also can't play until you've clicked once in the window — a browser autoplay rule.

---

## Project layout

```
Parts Bin.html          markup + ordered script includes
css/base.css            base styles, themes, components
css/styles-presets.css  the 7 style presets (one self-contained block each)
js/01-core.js           state, storage, recovery, utilities
js/02..11               inventory, projects, orders, archive, compartments,
                        items, labels, scanner, settings, backup
js/12-styles.js         style registry + apply
js/13-app.js            boot sequence
js/14-live.js           live clock + auto-receive
js/15-uninstall.js      uninstall flow
js/16-celebrate.js      confetti
js/17-support.js        support links
js/18-notify.js         notification centre + sounds
js/19-whatsnew.js       update tour
assets/                 icon, barcode engine, cloud-sync notes
```

**Adding a style preset** is two steps: one entry in `STYLES` (`js/12-styles.js`) and one
`body[data-style="key"]{…}` block in `css/styles-presets.css`. It then appears in Settings automatically.

---

## Support

* Discord — https://discord.gg/n8M3V4SaHJ
* YouTube — https://www.youtube.com/@PrintLab3D000
* TikTok — https://www.tiktok.com/@printlab3d64
* Email — PrintLab3D@outlook.com.au

---

Built by PrintLab3D.
